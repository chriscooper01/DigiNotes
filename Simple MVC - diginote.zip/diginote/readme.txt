Pics from
https://pixabay.com/en/reminder-sticky-notes-colorful-791271/